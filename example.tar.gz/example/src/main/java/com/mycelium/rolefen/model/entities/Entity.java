package com.mycelium.rolefen.model.entities;

public interface Entity {
	public long getId();
	public void setId(long id);
}
